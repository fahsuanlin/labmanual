function matrix = GetSignalParavision(xres,yres,slicenum,pathname)


%pathname is the location of the 2dseq file you want to look at and save.
%slicenum is the number of images in the series

close all;
clear matrix;

cd('Z:\Experiments\');

%[pathname] = uigetdir('Pick the directory containing the data');
%pathname = 'Z:\Experiments\STTARR\June 19, 2008\19-06-08.NY1\12\pdata\2';
cd([pathname]);

%if you are getting noise, try using 'b' instead of 'l' as the endian
%option for fopen.  

rawdata = fopen('2dseq', 'r', 'l');
data = fread(rawdata,'short');

length(data);

 ctr = 1;
 for slice = 1:slicenum
     slice;
     for j = 1:yres
         for k = 1:xres
             matrix(j,k,slice) = data(ctr);
             ctr = ctr+1;
         end
     end
 end

for slice = 1:slicenum
    figure;
    imshow(abs(matrix(:,:,slice)), []);
end

%save matrix matrix







