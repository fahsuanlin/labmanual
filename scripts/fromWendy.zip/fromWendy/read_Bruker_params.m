% this function parses the different parameter files
function params = read_Bruker_params(filepath,debug_msgs)
if(exist(filepath,'file')==2)
    if(debug_msgs)
        disp(['reading parameters from ' filepath]);
    end
    fid = fopen(filepath, 'r');
    flag_reading_matrix = false;
    while 1
        tline = fgetl(fid);
        if(flag_reading_matrix)
            if(~ischar(tline) || ~isempty(regexp(tline,'^#')) ...
               || ~isempty(regexp(tline,'^\$')))
                flag_reading_matrix = false;
                
                % if the parameter matrix is numeric, convert it
                if(length(regexp(matrix,'[\s\d\.]+')) && isnumeric(str2num(matrix)))
                    matrix = str2num(matrix);
                end
                if(length(matrix(:))==prod(param_size))
                    % resize according to the param_size, and flip the
                    % first 2 dimensions
                    matrix = permute(reshape(matrix,param_size),[2 1 3:length(param_size)]);
                end
                eval(['params.' param_name '=matrix;']);
            else
                % add elements to the current paramter matrix
                matrix = [matrix char(tline)];
            end
        end
        if ~ischar(tline) break; % end of file
        else
            % if this regexp matches, we are going to be reading in
            % multiple lines into a matrix
            n = regexp(tline,'##\$(.+)=\( (.+) \)$','tokens','once');
            if(~isempty(n))
                flag_reading_matrix = true;
                param_name = char(n(1));
                
                size_str = char(n(2));
                param_size = [];
                while ~isempty(size_str)
                    [t,size_str] = strtok(size_str,', ');
                    param_size = [param_size str2num(char(t))];
                end
                % size must be at least 2 dimension
                if(length(param_size)==1)
                    param_size = [param_size 1];
                end
                % flip dimensions 1 and 2
                param_size = [param_size(2) param_size(1) param_size(3:end)];
                matrix = [];
            else
                % if this regexp matches, we have a single line parameter
                n = regexp(tline,'##\$(.+)=(.+)$','tokens','once');
                if(~isempty(n))
                    param_name = char(n(1));
                    param_value = str2num(char(n(2)));
                    if(isempty(param_value))
                        param_value = char(n(2));
                    end
                    eval(['params.' param_name '=param_value;']); continue;
                end
            end
        end
    end    
    fclose(fid);
else
   error([filepath ' does not exist']);
end