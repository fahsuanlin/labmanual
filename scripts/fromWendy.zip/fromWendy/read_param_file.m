function params = read_param_file(filepath,debug_msgs)
if(exist(filepath,'file')==2)
    if(debug_msgs)
        disp(['reading parameters from ' filepath]);
    end
    fid = fopen(filepath, 'r');
    flag_reading_matrix = false;
    while 1
        tline = fgetl(fid);
        %if strfind(tline,'<5.1>'), disp(filepath), disp(tline), end
        if(flag_reading_matrix)
            if(~ischar(tline) || ~isempty(regexp(tline,'^#')) ...
               || ~isempty(regexp(tline,'^\$')))
                flag_reading_matrix = false;
                
                % if the parameter matrix is numeric, convert it
                %if(~isempty(regexp(matrix,'[\s\d\.]+')) && isnumeric(str2num(matrix)))
                % lamw: isnumeric(str2num(matrix)) thinks <5.1> is numeric,
                %       when it is not, and converts it to NULL. Fix this.
                if(~isempty(regexp(matrix,'[\s\d\.]+')) && ~isempty(str2num(matrix)) && isnumeric(str2num(matrix)))
                    matrix = str2num(matrix);
                end
                if(length(matrix(:))==prod(param_size))
                    % resize according to the param_size, and flip the
                    % first 2 dimensions
                    matrix = permute(reshape(matrix,param_size),[2 1 3:length(param_size)]);
                end
                eval(['params.' param_name '=matrix;']);
            else
                % add elements to the current paramter matrix
                matrix = [matrix char(tline)];
            end
        end
        if ~ischar(tline) break; % end of file
        else
            % if this regexp matches, we are going to be reading in
            % multiple lines into a matrix
            n = regexp(tline,'##\$(.+)=\( (.+) \)$','tokens','once');
            if(~isempty(n))
                flag_reading_matrix = true;
                param_name = char(n(1));
                
                size_str = char(n(2));
                param_size = [];
                while ~isempty(size_str)
                    [t,size_str] = strtok(size_str,', ');
                    param_size = [param_size str2num(char(t))];
                end
                % size must be at least 2 dimension
                if(length(param_size)==1)
                    param_size = [param_size 1];
                end
                % flip dimensions 1 and 2
                param_size = [param_size(2) param_size(1) param_size(3:end)];
                matrix = [];
            else
                % if this regexp matches, we have a single line parameter
                n = regexp(tline,'##\$(.+)=(.+)$','tokens','once');
                if(~isempty(n))
                    param_name = char(n(1));
                    param_value = str2num(char(n(2)));
                    if(isempty(param_value))
                        param_value = char(n(2));
                    end
                    eval(['params.' param_name '=param_value;']); continue;
                end
            end
        end
    end    
    fclose(fid);
else
   error([filepath ' does not exist']);
end