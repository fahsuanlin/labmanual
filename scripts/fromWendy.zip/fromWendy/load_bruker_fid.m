function [im, params, R, I] = load_bruker_fid(varargin)

rescale_recon = false;
flip_phase = false;
debug_msgs=false;
filter = 0;

% if varargin is odd, we assume that the filepath is the first parameter
if(rem(length(varargin),2))
    filepath = varargin{1};
    if(length(varargin)>1)
        varargin = varargin([2:end]);
    else
        varargin = [];
    end
else % otherwise, assume that filepath is empty
    filepath = [];
end

% check options
for i=1:floor(length(varargin)/2)
    option=varargin{i*2-1};
    option_value=varargin{i*2};
    switch lower(option)
    case 'rescale_recon'
    	rescale_recon=option_value;
    case 'flip_phase'
        flip_phase=option_value;     
    case 'debug'
    	debug_msgs=option_value;
    case 'filter'
        filter = option_value;
    otherwise
        fprintf('unknown option [%s]!\n',option);
        fprintf('error!\n');
        return;
    end;
end;

% parameter values to output
params = [];

% if there was no filepath input, get one using a file selection dialog box
if(nargin==0 || isempty(filepath))
    [filename,imagepath] = uigetfile('*.*', 'Select fid File','fid');
    filepath = [imagepath filename];
else
    ind = strfind(filepath,'\');
    imagepath = filepath(1:ind(end));
    filename = filepath(ind(end)+1:end);
end

% check the d3proc file
%params.d3proc = read_param_file([imagepath '\pdata\1\d3proc'],debug_msgs);

% check the reco file
params.reco = read_param_file([imagepath '\pdata\1\reco'],debug_msgs);

% check the method file
params.method = read_param_file([imagepath '\method'],debug_msgs);

% check the acqp file
params.acqp = read_param_file([imagepath '\acqp'],debug_msgs);

% check the visu file
params.visu = read_param_file([imagepath '\pdata\1\visu_pars'],debug_msgs);

% read the image data
if(strcmp(params.acqp.BYTORDA,'little'))
    fid = fopen([imagepath '\fid'], 'r', 'l');
else
    fid = fopen([imagepath '\fid'], 'r', 'b');
end
if(strcmp(params.acqp.ACQ_word_size,'_32_BIT'))
    data = fread(fid,'long');
else
    data = fread(fid,'short');
end
%    S = permute(reshape(data,[params.visu_pars.VisuCoreSize(2) params.visu_pars.VisuCoreSize(1) params.acqp.NSLICES params.acqp.NR params.acqp.ACQ_n_movie_frames]),[2 1 3 4 5]);

R = permute(reshape(data(1:2:end), [params.acqp.ACQ_size(1) params.acqp.NECHOES params.acqp.ACQ_size(2) params.acqp.NSLICES]), [3 1 2 4]);
I = permute(reshape(data(2:2:end), [params.acqp.ACQ_size(1) params.acqp.NECHOES params.acqp.ACQ_size(2) params.acqp.NSLICES]), [3 1 2 4]);
%R = permute(reshape(data(1:2:end), [params.method.PVM_EncMatrix(1) params.d3proc.IM_SIZ params.method.PVM_EncMatrix(2) params.d3proc.IM_SIT]), [3 1 2 4]);
%I = permute(reshape(data(2:2:end), [params.method.PVM_EncMatrix(1) params.d3proc.IM_SIZ params.method.PVM_EncMatrix(2) params.d3proc.IM_SIT]), [3 1 2 4]);
%I = permute(reshape(data(2:2:end), [params.d3proc.IM_SIX params.d3proc.IM_SIZ params.d3proc.IM_SIY params.d3proc.IM_SIT]), [3 1 2 4]);
%I = permute(reshape(data(2:2:end), [128 128 200]), [3 1 2]);
%R = [zeros(28, 128,128); R; zeros(28, 128, 128)];
%I = [zeros(28, 128,128); I; zeros(28, 128, 128)];

shiftx = floor(params.reco.RECO_rotate(1,1)*params.acqp.ACQ_size(1));
shifty = floor(params.reco.RECO_rotate(2,1)*params.acqp.ACQ_size(2));

if (filter)
    filt = apodizationFunc([params.acqp.ACQ_size(2) params.acqp.ACQ_size(1)], filter);
else
    filt = ones(params.acqp.ACQ_size(2), params.acqp.ACQ_size(1));
end

%im = ifftshift(ifft2(fftshift(repmat(filt, [1 1 params.d3proc.IM_SIZ]).*(R+I*1i),2)),2);
im = ifftshift(ifft2(fftshift(R+I*1i,2)),2);
%im = circshift(abs(im), [shifty, shiftx]);
im = circshift(abs(im), [shifty, 0]);
k=10;
%subplot(2,2,1)
imagesc(im(:,:,10))
%subplot(2,2,3)
%imagesc(R(:,:,k))
%subplot(2,2,4)
%imagesc(I(:,:,k))

% this function parses the different parameter files
function params = read_param_file(filepath,debug_msgs)
if(exist(filepath,'file')==2)
    if(debug_msgs)
        disp(['reading parameters from ' filepath]);
    end
    fid = fopen(filepath, 'r');
    flag_reading_matrix = false;
    while 1
        tline = fgetl(fid);
        if(flag_reading_matrix)
            if(~ischar(tline) || ~isempty(regexp(tline,'^#')) ...
               || ~isempty(regexp(tline,'^\$')))
                flag_reading_matrix = false;
                
                % if the parameter matrix is numeric, convert it
                if(length(regexp(matrix,'[\s\d\.]+')) && isnumeric(str2num(matrix)))
                    matrix = str2num(matrix);
                end
                if(length(matrix(:))==prod(param_size))
                    % resize according to the param_size, and flip the
                    % first 2 dimensions
                    matrix = permute(reshape(matrix,param_size),[2 1 3:length(param_size)]);
                end
                eval(['params.' param_name '=matrix;']);
            else
                % add elements to the current paramter matrix
                matrix = [matrix char(tline)];
            end
        end
        if ~ischar(tline) break; % end of file
        else
            % if this regexp matches, we are going to be reading in
            % multiple lines into a matrix
            n = regexp(tline,'##\$(.+)=\( (.+) \)$','tokens','once');
            if(~isempty(n))
                flag_reading_matrix = true;
                param_name = char(n(1));
                
                size_str = char(n(2));
                param_size = [];
                while ~isempty(size_str)
                    [t,size_str] = strtok(size_str,', ');
                    param_size = [param_size str2num(char(t))];
                end
                % size must be at least 2 dimension
                if(length(param_size)==1)
                    param_size = [param_size 1];
                end
                % flip dimensions 1 and 2
                param_size = [param_size(2) param_size(1) param_size(3:end)];
                matrix = [];
            else
                % if this regexp matches, we have a single line parameter
                n = regexp(tline,'##\$(.+)=(.+)$','tokens','once');
                if(~isempty(n))
                    param_name = char(n(1));
                    param_value = str2num(char(n(2)));
                    if(isempty(param_value))
                        param_value = char(n(2));
                    end
                    eval(['params.' param_name '=param_value;']); continue;
                end
            end
        end
    end    
    fclose(fid);
else
   error([filepath ' does not exist']);
end