function create_bruker_scan_documentation(scan_dir,output_csv_file)
% create_bruker_scan_documentation(scan_dir,output_csv_file)
% 
% Create a csv file with information on all Bruker image folders within a
% directory.
%
% scan_dir;         % if this is blank, the user will be prompted with a
%                   % dialog box.
% output_csv_file   % path to the output file.  Default is
%                   % "scan_dir scan list.csv"
%
% Author: Ryan Fobel
%         ryan@fobel.net

% A list of common parameters
%
% params.reco.RecoNumInputChan; % number of channels
% params.method.Method; % method (e.g. RARE, DtiEpi)
% params.acqp.RG; % receiver gain
% params.acqp.ACQ_echo_time; % TE (ms)
% params.acqp.ACQ_repetition_time; % TR (ms)
% params.acqp.ACQ_slice_offset; % offset from isocentre in slice direction (mm)
% params.acqp.ACQ_slice_thick; % slice thickness (mm)
% params.acqp.ACQ_read_offset; % offset from isocentre in read direction (mm) 
% params.acqp.ACQ_phase1_offset; % offset from isocentre in phase direction (mm)
% params.acqp.ACQ_fov; % Field of View (cm)
% params.method.PVM_Matrix; % matrix dimensions
% params.method.PVM_SPackArrReadOrient; % readout direction
% params.method.PVM_SelIrInvTime; % inversion time (ms)

% if no directory was passed in as an argument, ask for it
if(nargin==0)
    [scan_dir] = uigetdir;
end
if(nargin<2)
    ind = strfind(scan_dir,'\');
    output_csv_file = [scan_dir(ind(end)+1:end) ' scan list.csv'];
end

cd(scan_dir);  %kld

% switch all backslashes to forward slashes
scan_dir(strfind(scan_dir,'\')) = '/';
d = dir(scan_dir);

% check for all of the image folders in this directory
series = [];
for j=1:length(d)
    n = str2num(d(j).name);
    if(n)
        series(j) = n;
    end
end
if(isempty(series))
    error('no bruker images found');
end

% sort them
[series,idx] = sort(series);

disp(['writing output to file: ' output_csv_file]);
fid = fopen(output_csv_file,'w');
fprintf(fid,'series,method,readout,TE,# echoes,TR,flip angle,# channels,TI,MT power,MT offset\n');
for j=1:length(series)
    if(series(j) && exist([scan_dir sprintf('/%d/pdata/1/2dseq',series(j))]))
        [S,params] = load_bruker_images([scan_dir sprintf('/%d/pdata/1/2dseq',series(j))]);

        readout_dir = [];
        if(isfield(params.method,'PVM_SPackArrReadOrient'))
            % replace _ with / in readout direction description
            readout_dir = params.method.PVM_SPackArrReadOrient;
            readout_dir(strfind(readout_dir,'_'))='/';
        end

        nchannels = [];
        if(isfield(params,'reco') && isfield(params.reco,'RecoNumInputChan'))
            nchannels = sprintf('%d',params.reco.RecoNumInputChan);
        end
            
        TI = [];
        if(isfield(params.method,'PVM_SelIrInvTime'))
            TI = sprintf('%d',params.method.PVM_SelIrInvTime);
        end
        MT = [];
        if(isfield(params.method,'PVM_MagTransOnOff'))
            MT = params.method.PVM_MagTransOnOff;
        end
        MT_power = [];
        if(isfield(params.method,'PVM_MagTransPower'))
            MT_power = sprintf('%.1f',params.method.PVM_MagTransPower);
        end
        MT_offset = [];
        if(isfield(params.method,'PVM_MagTransOffset'))
            MT_offset = sprintf('%d',params.method.PVM_MagTransOffset);
        end
        if(TI)
            desc = [sprintf('%d,',series(j)) 'IR ' params.method.Method];
        elseif(strcmpi(MT,'On'))
            desc = [sprintf('%d,',series(j)) 'MT ' params.method.Method];
        else
            desc = [sprintf('%d,',series(j)) params.method.Method];
        end
        disp(['Series ' desc]);
        desc = [desc sprintf([',' readout_dir ...
            ',%.1f,%d,%d,%.1f,' nchannels ',' TI ',' MT_power ',' MT_offset],...
            params.acqp.ACQ_echo_time(1),length(params.acqp.ACQ_echo_time),round(params.acqp.ACQ_repetition_time),...
            params.acqp.ACQ_flip_angle)];
        fprintf(fid,[desc '\n']);
    end
end
fclose(fid);