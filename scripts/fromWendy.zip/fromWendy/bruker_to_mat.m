
function bruker_to_mat(rootpath, series)

%rootpath is the folder containing all the data for that day
%series is a vector of the series that you want to reconstruct into .mat files


for i = [series]
    ['[S' num2str(i) ', params] = load_bruker_images(''' rootpath num2str(i) '/pdata/1/'', ''rescale_recon'', ''true''' ');']
    eval(['[S' num2str(i) ', params] = load_bruker_images(''' rootpath num2str(i) '/pdata/1/'', ''rescale_recon'', ''true''' ');'])
%    ['[S' num2str(i) ', params] = load_bruker_images_windows(''' rootpath num2str(i) '\pdata\1\'', ''rescale_recon'', ''true''' ');']

%    eval(['[S' num2str(i) ', params] = load_bruker_images_windows(''' rootpath num2str(i) '\pdata\1\'', ''rescale_recon'', ''true''' ');'])
end

cd(rootpath);

for i = [series]
    eval(['matrix = S' num2str(i) ';'])
    eval(['save S' num2str(i) '.mat matrix'])
end
