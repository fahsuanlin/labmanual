data_dir = pwd;
if ispc, dirsep = '\';
else     dirsep = '/';
end

clear expnum scan_details

D = dir(data_dir);
sercount = 0; % Series count
for i = 1:numel(D)
    if D(i).isdir && exist([data_dir dirsep D(i).name dirsep 'fid' ],'file')
        sercount = sercount + 1;
        expnum(sercount) = str2double(D(i).name);
    end
end
expnum = sort(expnum);

for i=1:numel(expnum)
    debug_msgs = false;
    % Read method file
    method = read_param_file([data_dir dirsep num2str(expnum(i)) dirsep 'method'],debug_msgs);
    % Read acqp file
    acqp = read_param_file([data_dir dirsep num2str(expnum(i)) dirsep 'acqp'],debug_msgs);
try
 disp([ '#' num2str(expnum(i)) ': TE = ' num2str(method.PVM_EchoTime) ', TR = ' num2str(method.PVM_RepetitionTime) ', TE1 = ' num2str(method.TE1) ', TE2 = ' num2str(method.TE2) ', num pts = ' num2str(method.PVM_SpecMatrix) ', NA = ' num2str(method.PVM_NAverages)])
 %disp([ '#' num2str(expnum(i)) ': TE = ' num2str(method.PVM_EchoTime) ', TR = ' num2str(method.PVM_RepetitionTime) ', AcqT = ' num2str(method.PVM_SpecAcquisitionTime) ', SW = ' num2str(method.PVM_SpecSW) ', num pts = ' num2str(method.PVM_SpecMatrix) ', Spoiler = ' num2str(method.SpoilerStrength)])
catch
end
    
try
     scan_details{i, 1} = expnum(i);
     scan_details{i, 2} = acqp.ACQ_scan_name(2:end-1);
     scan_details{i, 3} = method.PVM_RepetitionTime;
     scan_details{i, 4} = method.PVM_EchoTime;
     scan_details{i, 5} = method.TE1;
     scan_details{i, 6} = method.TE2;
     scan_details{i, 7} = method.PVM_SpecMatrix;
     scan_details{i, 8} = method.PVM_NAverages;
catch
end
end

%%
fid = fopen([data_dir dirsep 'MRS scan details.txt'],'w');
fprintf(fid,'Exp        Series Name    TR/ TE     TE1/TE2   Points   Averages  \n');
for i = 1:sercount
    
        fprintf(fid,'%2.f %18s  TR/TE:%4.f/%3.fms TE1/TE2:%4.f/%3.fms  Points:%3.f NA:%4.fms  %s \n\n',scan_details{i,1:end});
end
fclose(fid);